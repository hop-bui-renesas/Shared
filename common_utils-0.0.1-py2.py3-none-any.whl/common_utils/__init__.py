"""Top-level package for pipelines."""

__author__ = """Bala Murugan N G"""
__email__ = 'balng@deloitte.com'
__version__ = '0.0.1'