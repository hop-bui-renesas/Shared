import logging

logging.basicConfig(filename="task.log",
                    format='%(asctime)s : %(levelname)s : %(filename)s : %(lineno)s: %(message)s',
                    filemode='w')

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

formatter = logging.Formatter(
    '%(asctime)s : %(levelname)s : %(filename)s : %(lineno)s: %(message)s'
)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(formatter)
logger.addHandler(stream_handler)
