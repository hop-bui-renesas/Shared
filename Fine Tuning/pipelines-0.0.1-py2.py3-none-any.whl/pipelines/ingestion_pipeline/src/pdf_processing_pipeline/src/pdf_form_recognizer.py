import os
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from .config import AZURE_FORM_RECOGNIZER_KEY, AZURE_FORM_RECOGNIZER_ENDPOINT, CHUNK_PAGE_SIZE, PDF_TABLES_FOLDER
import pandas as pd
import json
from common_utils.logging_utils import logger
from tabulate import tabulate
from anyascii import anyascii
from concurrent.futures import ThreadPoolExecutor
import glob
import numpy as np
import re

class AzureFormRecognizer():
    # formatting function
    def __init__(self):
        self.document_analysis_client = DocumentAnalysisClient(
            endpoint=AZURE_FORM_RECOGNIZER_ENDPOINT, credential=AzureKeyCredential(AZURE_FORM_RECOGNIZER_KEY)
        )

        self.foldername = PDF_TABLES_FOLDER
        if not os.path.exists(self.foldername):
            os.mkdir(self.foldername)
        
    def table_extraction(self, filename_for_metadata, result, page_chunk_count, page_url= "None"):
        # with open("results.json", "w") as f:
        #     json.dump(result.to_dict(), f)

        logger.info("Getting inside Table extraction")
        
        table_list = []
        metadata = []
        tbl_mkfolder = os.path.join(self.foldername, f"{filename_for_metadata.split('.pdf')[0]}")
        if not os.path.exists(tbl_mkfolder):
            os.mkdir(tbl_mkfolder)
        try:
            for index, table in enumerate(result.tables):
                # print(f"Table: {index}")
                df = pd.DataFrame()
                page_number_list = []
                for cell in table.cells:
                    df.loc[cell.row_index, cell.column_index] = anyascii(cell.content)
                    for i in cell.bounding_regions:
                        page_number_list.append(i.page_number)
                df.columns = df.iloc[0]
                df.drop(df.index[0], inplace=True)
                df.replace("", np.nan, inplace=True)
                df.dropna(axis = 0, how = "all", inplace=True)
                # df.drop_duplicates(inplace=True)

                # logger.info("Creating CSV Files")
                real_pagenumber = (int(CHUNK_PAGE_SIZE) * int(page_chunk_count)) + int(max(page_number_list))
                filename = os.path.join(tbl_mkfolder, f"{filename_for_metadata.split('.pdf')[0]}_page_{real_pagenumber}_table_{index}.csv")

                df.to_csv(filename, index = False)
                table_list.append(filename)

                # logger.info(f"PDF FILENAME tables : {filename}")
                # logger.info(f"PDF PAGENO tables{(int(CHUNK_PAGE_SIZE) * int(page_chunk_count))+ int(max(page_number_list))}")

                metadata.append({
                    "source_document_link" : page_url,
                    "filename" : filename_for_metadata,
                    "page_number" : real_pagenumber,
                    "section_header" : ""
                })
            # print(tabulate(df, headers='keys', tablefmt='fancy_grid'))
        except Exception as e:
            logger.error(f"Error on Table Processing: {str(e)}")

        try:
            logger.info(f"Tables stored under {tbl_mkfolder}")
        except:
            pass
        
        return {
            "Table" : table_list,
            "metadata" : metadata
            }     
                       
    def text_extraction(self, filename_for_metadata, result, page_chunk_count, page_url = "None"):

        logger.info("Getting inside text extraction")

        try:
            total_page_content = []
            metadata = []
            for page in result.pages:
                # logger.info(page)
                total_page_content.append(" ".join([line.content for line in page.lines]).replace("\n", " ").replace("\t",""))

                # logger.info(f"PDF FILENAME pdf: {filename_for_metadata}")
                # logger.info(f"PDF PAGENO pdf{(int(CHUNK_PAGE_SIZE) * int(page_chunk_count)) + int(page.page_number)}")

                metadata.append({
                    "source_document_link" : page_url,
                    "filename" : filename_for_metadata,
                    "page_number" : (int(CHUNK_PAGE_SIZE) * int(page_chunk_count)) + int(page.page_number),
                    "section_header" : ""
                })
            
            return {
                "Text" : total_page_content,
                "metadata" : metadata
                }
        except Exception as e:
            logger.error(f"Error on Text Processing: {e}")
            pass
            
    
        # page_content_list=[page.get_text().replace("\n", " ").replace("\t","") for page in self.extracted_output.pages]
        # page_content_list = self.remove_garbage_text(page_content_list)
        # metadata_list = [{"source": self.input_file, "page":i+1} for i in range(len(self.extracted_output.pages))]  
    
    def thread_execution_call(self, pdf_path, page_chunk_count, page_url):

        logger.info(f"Processing PDF File: {pdf_path}")

        filename_for_metadata = re.sub(r"_page_\d+_\d+", "", os.path.basename(pdf_path))

        with open(pdf_path, "rb") as open_pdf_file:
            poller = self.document_analysis_client.begin_analyze_document(
                "prebuilt-layout", open_pdf_file
            )
            result = poller.result()

            # logger.info(f"Resulf from Form Recognizer {result}")
        
        logger.info("Text Extraction Started")
        text_output = self.text_extraction(filename_for_metadata, result, page_chunk_count, page_url)
        logger.info("Text Extraction Completed")
        logger.info("Table Extraction Started")
        table_output = self.table_extraction(filename_for_metadata, result, page_chunk_count, page_url)
        logger.info("Table Extraction Completed")
        self.document_analysis_client.close()

        return text_output, table_output

    def form_recognize(self, pdf_path, page_chunk_count, page_url = "None"):

        text_output, table_output = self.thread_execution_call(pdf_path, page_chunk_count, page_url)

        return text_output, table_output
    
        # logger.info("Form Recognizer Output: %s", form_recognizer_output)