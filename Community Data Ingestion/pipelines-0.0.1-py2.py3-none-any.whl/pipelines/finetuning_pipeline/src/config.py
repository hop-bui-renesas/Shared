DATABRICKS_WORKSPACE_URL  = "https://adb-2804723707680916.16.azuredatabricks.net/"
DATABRICKS_MPT30B_ENDPOINT = "mpt-7b-8k-qlora-fine-tuned"
DATABRICKS_PERSONAL_ACCESS_TOKEN = "dapi862bdd4b333124fa3219f9506547ffaf"
max_length = 512
temperature = 0.00001