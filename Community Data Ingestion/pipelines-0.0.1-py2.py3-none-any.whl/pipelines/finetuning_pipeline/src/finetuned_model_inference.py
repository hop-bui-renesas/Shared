from langchain_community.llms.databricks import Databricks
from .config import DATABRICKS_WORKSPACE_URL, DATABRICKS_PERSONAL_ACCESS_TOKEN, DATABRICKS_MPT30B_ENDPOINT, temperature, max_length
from common_utils.logging_utils import logger
# from pipelines.prompts_store.prompts import rag_system_prompt

def transform_output(response):
    return response.get('candidates')[0]['text']

def finetuned_inference(query, endpoint_name = DATABRICKS_MPT30B_ENDPOINT):

    logger.info(f"Finetuned Serving Endpoint Name : {endpoint_name}")

    llm = Databricks(host = DATABRICKS_WORKSPACE_URL, endpoint_name=endpoint_name,
                        api_token=DATABRICKS_PERSONAL_ACCESS_TOKEN,  transform_output_fn=transform_output,
                        temperature = temperature, max_tokens = max_length, verbose = True, extra_params={"temperature": 0.1, "max_tokens" : 512})
    
    return llm(query)