from common_utils.logging_utils import logger
from sympy import product
from .config import DEFAULT_LLM_MODEL, DEFAULT_MAX_LENGTH, DEFAULT_TEMPERATURE, DEBUG_MODE, AI_SEARCH_INDEX_NAME
from .retrieval_search import RetrievalSearch
from pipelines.prompts_store.prompts import condense_question_system_prompt, condense_question_user_prompt,\
      rag_user_prompt_v2, rag_system_prompt_v4, rag_prompt
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.prompts import HumanMessagePromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain, RetrievalQA, LLMChain

from transformers import AutoTokenizer, pipeline
from langchain_community.llms.huggingface_pipeline import HuggingFacePipeline
from langchain_community.llms.databricks import Databricks
from pipelines.llm_hub.llms import LLMHub
from langchain.prompts import PromptTemplate
import json
from anyascii import anyascii
import ast
import re

class QARAGPipeline():
    """
    This class is designed to run RAG on the documents within the Azure AI Search Index. 

    This will take a query as input, retrieve the documents from the Index, and return a response from the LLM

    Response: Text response and source documents
    """
    def __init__(self, index = AI_SEARCH_INDEX_NAME, reranker = True) -> None:
        """
        Initializ the class with the index and reranker (for Azure AI Search additional re ranker is not used)
        - This is from the rag_pipeline folder originally for Databricks Vector Search which does not have a native reranker
        """
        if reranker == True:
            self.topk = 4 # semantic reranker in Azure AI Search can only fetch top 50 docs.
            self.top_n = 6
        elif reranker == False:
            self.topk = 4
            self.top_n = 4
        logger.info(f"Values for TopK & Top N : {self.topk}, {self.top_n}")
        self.rag_search = RetrievalSearch(index_name=index, topk = self.topk, top_n = self.top_n)
        logger.info("RAG Retriever Initialized")

        self.reranker = reranker

        self.llm = LLMHub().databricks_llm()
        # Use the Chat model Mixtral 8x7B Foundation model endpoints from databricks  
        # self.llm = LLMHub().chat_databricks_llm()
    
    def retrieval_qa(self, question, system_prompt, user_prompt, retriever):
        """
        This function calls the RetrievalQA chain to get the response from the LLM

        Inputs: 
        - question <string>: User Query
        - system_prompt <string>: System Prompt from prompt store
        - user_prompt <string>: User Prompt from prompt store (UNUSED)
        - retriever <object>: Langchain Retriever object using Azure AI Search Vector Index 

        Outputs:
        - chain_response <dict>: Response from the LLM, Text Chunks, and Source Documents
        """
        myprompt = system_prompt
        prompt_template = (
            PromptTemplate.from_template(myprompt)                
        )

        chain_type_kwargs = {"prompt": prompt_template,
                                 "verbose": DEBUG_MODE}
        
        chain = RetrievalQA.from_chain_type(llm=self.llm, retriever=retriever,
                                                chain_type_kwargs=chain_type_kwargs,
                                                return_source_documents=True)
        chain_response = chain({'query': question})
        return chain_response
    
    def customize_response(self, response, query, base_retriever_out= None, chat_history = None):
        """
        This function customizes the response from the LLM to return the metadata and supporting content

        The response is customized in a specific way due to how data is passed to the front end

        Inputs:
        - response <string>: Text response from the LLM
        - query <string>: User Query
        - base_retriever_out <dict>: Response from RAG and list of documents from the Azure AI Search Index
        - chat_history <list>: List of chat history (UNUSED)

        Outputs: 
        - formatted_response <dict>: Customized response with metadata and supporting content
        """
        
        result = response
        mt = []
        mt_data = []
        supporting_content = []

        # RERANKER MUST ALWAYS BE TRUE FOR AZURE AI SEARCH EVEN THOUGHT IT IS NOT USED
        if self.reranker == False:
            for i in mt:
                myjson =  i.metadata
                myjson['source_document'] = myjson['filename']
                # myjson = json.loads(str(i.metadata['metadata']).replace('"', "'").replace("'", '"'))
                mt_data.append(myjson)
                # Return the page content
                supporting_content.append(i.page_content)
        elif self.reranker == True:
                base_retriever_metadata = []
                # Using the resposne from RAG reformat the metadata documents and scores
                for i, _, reranker_score in base_retriever_out:
                    askjson = i.metadata
                    askjson['ai_search_reranker_score'] = reranker_score
                    base_retriever_metadata.append(askjson)
                if base_retriever_out is not None:
                    support_chunks = [doc.page_content for doc, _, _ in base_retriever_out]
                    supporting_content.extend(support_chunks)            
        result_filter = ["I don't know the answer to your question. I don't have enough context to answer the question" for i in base_retriever_metadata if i['ai_search_reranker_score'] < 0.5]

        if len(result_filter) > 0:
            # result = result_filter[0]
            base_retriever_metadata = []
            # supporting_content = []

        return {
            "query" : query,
            "response" : result,
            "chat_history" : chat_history,
            "metadata" : base_retriever_metadata,
            "supporting_content": supporting_content
        }

    def conversational_qa(self, question, system_prompt, user_prompt, retriever, chat_history):
        
        myprompt = system_prompt+"\n"+user_prompt
        prompt_template = ( 
                            PromptTemplate.from_template(myprompt)
                            +"{chat_history}"
                            +"{question}"
                        )

        chat_memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True, output_key='answer')
        chain = ConversationalRetrievalChain.from_llm(self.llm,
                                                        retriever=retriever,
                                                        memory=chat_memory,
                                                        condense_question_prompt=prompt_template,
                                                        return_source_documents=True,
                                                        verbose=False)
        logger.info("Started Chain with Chat History")
        logger.info(f"Chat History going inside chain : {chat_history}")
        chain_response = chain({"question": question, "chat_history": chat_history})
        # logger.info(f"Response obtained: {response}")
        try:
            chat_history.append((question, chain_response["answer"]))
        except Exception as e:
            logger.info("Chat history error")

        return chain_response, chat_history 

    def qa_pipeline(self, query, system_prompt = rag_prompt, user_prompt = rag_user_prompt_v2, chat_history = None):
        """
        Primary RAG orchestration which retrieves documents from the Index and runs the LLM

        TODO - Implement chat history usage for the application

        Inputs:
        - query <string>: User Query
        - system_prompt <string>: System Prompt from prompt store
        - user_prompt <string>: User Prompt from prompt store (UNUSED)
        - chat_history <list>: List of chat history (UNUSED)

        Outputs:
        - formatted_response <dict>: Customized response with metadata and supporting content
        """
        query = re.sub(r'[?.!]', '', query.lower()) # remove ? from query

        entities_matched = re.findall(r"da\d+x|da\d{5}|ra\d+[0-9a-z]+", query)

        # Used to match to product family names i.e. DA14697 will match DA1469x
        if len(entities_matched) > 0:
            entities_matched = ",".join(entities_matched)
            split = entities_matched.lower().split(',')
            prefix = []
            for item in split:
                if "da" in item:
                    pre_1 = item[:5]+"xx"
                    pre_2 = item[:6]+"x"
                    prefix.append(pre_1) if pre_1 not in prefix else None
                    prefix.append(pre_2) if pre_2 not in prefix else None
                    for i, pre in enumerate(prefix):
                        if pre not in entities_matched: 
                            entities_matched = entities_matched+","+pre
        else:
            entities_matched = None

        print("ENTITIES MATCHED", entities_matched)

        # define the retriever object with the right filters
        retriever = self.rag_search.rag_retriever(entities_matched)

        # TODO - IN CURRENT SOLUTION CHAT HISTORY WILL ALWAYS BE NONE
        if chat_history == None:
            # TODO - remove all reranker references because Azure AI Search natively does the reranking with Hybrid Semantic search
            if self.reranker == True:
                # Directly call the semantic search and get the response with Source Documents
                base_retriever_out = self.rag_search.semantic_search_with_reranker_score(query, entities_matched) # to get the semantic reranker score
                
                # Create the context to pass to the LLM
                context = ""
                for i, (doc, _, _) in enumerate(base_retriever_out):
                    product_name = doc.metadata['product']
                    content = doc.page_content
                    if product_name:
                        context += f"Context {i+1} - Product Name: " + doc.metadata['product'] + "\n"
                    else:
                        context += f"Context {i+1}: - General Context\n"
                    content = re.sub(r"\n{2,}", "\n", content)

                    context+=content+"\n==============\n"

                print("Context: ", context)
                
                rag_prompt = PromptTemplate(
                    template=system_prompt, input_variables=["question", "context"]
                )

                rag_message_prompt = HumanMessagePromptTemplate(prompt=rag_prompt)

                chat_prompt = ChatPromptTemplate.from_messages(
                    [rag_message_prompt])
               
                rag_chain = LLMChain(llm = self.llm, prompt=chat_prompt)
                response = rag_chain.run(question= query, context = context)
                print("\nCHAIN RESPONSE: ", anyascii(response))
                formatted_response  = self.customize_response(response, query, base_retriever_out = base_retriever_out, chat_history = chat_history)
            elif self.reranker == False:
                # TODO - Remove all reranker references (FALSE CASE NOT USED)
                response = self.retrieval_qa(question=query, system_prompt = system_prompt, user_prompt = user_prompt, retriever = retriever)
                formatted_response  = self.customize_response(response, chat_history = chat_history)
            return formatted_response

        elif chat_history is not None:
            # TODO - Implement chat history for usage in current application however this does not need to be an extra condition with completely different code
            logger.info("Entering inside Chat History")
            if self.reranker == True:
                base_retriever_out = retriever.get_relevant_documents(query)
                # logger.info(base_retriever_out)
                compressed_reranked_retriever = self.rag_search.compress_reranker(retriever)

                response, chat_history = self.conversational_qa(question=query, system_prompt = condense_question_system_prompt, user_prompt = condense_question_user_prompt, retriever = compressed_reranked_retriever, chat_history = chat_history)

                formatted_response  = self.customize_response(response, base_retriever_out = base_retriever_out, chat_history = chat_history)
            
            elif self.reranker == False:
                response, chat_history = self.conversational_qa(question=query, system_prompt = condense_question_system_prompt, user_prompt = condense_question_user_prompt, retriever = retriever, chat_history=chat_history)

                formatted_response  = self.customize_response(response, chat_history = chat_history)

            print("Response from Conversational QA", formatted_response)

            return formatted_response

    