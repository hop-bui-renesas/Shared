from html import entities
from warnings import filters
from langchain.vectorstores.databricks_vector_search import DatabricksVectorSearch
from langchain_community.embeddings import HuggingFaceEmbeddings
from common_utils.logging_utils import logger
from sympy import N
from .config import DATABRICKS_PERSONAL_ACCESS_TOKEN, DEFAULT_EMBEDDING_MODEL, \
    DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME, DATABRICKS_WORKSPACE_URL, \
    DATABRICKS_PERSONAL_ACCESS_TOKEN, AI_SEARCH_ENDPOINT, AI_SEARCH_ACCESS_TOKEN
from databricks.vector_search.client import VectorSearchClient
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors.flashrank_rerank import FlashrankRerank
from langchain_community.vectorstores.azuresearch import AzureSearch
from langchain_community.vectorstores.azuresearch import AzureSearchVectorStoreRetriever
from langchain_community.retrievers import (
    AzureCognitiveSearchRetriever,
)
class RetrievalSearch():
    """Search on a vector store and returning relevant documents
       Inputs: 
       a. Search Query
       b. Selected List of documents by user to restrict search to -- applies only when you are interested in returning a retriever object
       c. Vector store index_name
       d. Top K parameter
    """
    def __init__(self,index_name,embeddings=DEFAULT_EMBEDDING_MODEL, topk=4, top_n = 4, search_type="semantic_hybrid"):
        try:
            self.embeddings= HuggingFaceEmbeddings(model_name = embeddings)
        except ValueError as e:
            logger.error("Error on Loading Huggingface Embedding Model")

        # self.client = VectorSearchClient(workspace_url=DATABRICKS_WORKSPACE_URL, 
        #                                  personal_access_token=DATABRICKS_PERSONAL_ACCESS_TOKEN)
        
        # index_name: str = "langchain-vector-demo-2"
            
        self.vector_store= AzureSearch(
            azure_search_endpoint=AI_SEARCH_ENDPOINT,
            azure_search_key=AI_SEARCH_ACCESS_TOKEN,
            index_name=index_name,
            embedding_function=self.embeddings,
            semantic_configuration_name = "semanticranker"
        )
                

        # try:
        #     listindexes = [idx['name'] for idx in self.client.list_indexes(name = DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME).get('vector_indexes', [])]
        #     print(listindexes)
        #     if index_name in listindexes:
        #         logger.info(f"Index : {index_name} exists inside Endpoint {DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME}")
        #         self.vs_index = self.client.get_index(
        #                             endpoint_name=DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME,
        #                             index_name=index_name)
                
        #         logger.info(f"VS Index : {self.vs_index}")

        #         self.vector_store = DatabricksVectorSearch(index=self.vs_index,
        #                                             embedding=self.embeddings,
        #                                             text_column="text",
        #                                             columns=['metadata']
        #                                                     )
        #         logger.info(f"Vector Store Index {self.vector_store}")
        #     else:
        #         raise Exception("Index Name is not Matching, try with other Index Name")
        # except Exception as e:
        #     logger.info(f"Exception: {e}")
            # logger.info(f"Index : {index_name} does not exists inside Endpoint {DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME}")

        self.topk=topk
        self.search_type=search_type
        self.top_n = top_n

    def compress_reranker(self, retriever, top_n = 4):

        logger.info("Entering inside Reranker")
        compressor = FlashrankRerank(model="rank-T5-flan", top_n = top_n)
        compression_retriever = ContextualCompressionRetriever(
                base_compressor=compressor, base_retriever=retriever
                )
        return compression_retriever

    def retrieve_similarity_search(self):
        search_kwargs={'k': self.topk}
        return self.vector_store.as_retriever(search_type=self.search_type,search_kwargs=search_kwargs)
    
    def retrieve_mmr_search(self, fetch_k = 2048, lambda_mult = 0.5):
        search_kwargs={'k': self.topk,'fetch_k':fetch_k, 'lambda_mult' : lambda_mult}
        return self.vector_store.as_retriever(search_type=self.search_type,search_kwargs=search_kwargs)
    
    def semantic_search_with_reranker_score(self, query, entities_matched):
        if entities_matched == None:
            filters = None
        else:
            filters=f"search.ismatchscoring('{','.join([entity+'~' for entity in entities_matched.split(',')])}', 'product')"

        print("FILTERS ON semantic_search_with_reranker_score", filters)
        return self.vector_store.semantic_hybrid_search_with_score_and_rerank(query, k = self.topk, filters = filters)
    
    def rag_retriever(self, entities_matched):
        if entities_matched == None:
            filters = None
        else:
            filters=f"search.ismatchscoring('{','.join([entity+'~' for entity in entities_matched.split(',')])}', 'product')"
        
        search_kwargs={'k': self.topk, "filters" : filters, "search_type" : self.search_type}
        print("SEARCH KWARGS rag_retriever", search_kwargs)
        return self.vector_store.as_retriever(search_kwargs = search_kwargs)
    
        # return AzureSearchVectorStoreRetriever(vectorstore=self.vector_store, k=self.topk, search_type=self.search_type, search_kwargs= search_kwargs)
    
    def rag_search_results(self,query=None):
        docs=self.vector_store.similarity_search(query=query,k=self.topk) # type: ignore
        return docs
    
    def rag_mmr_search_results(self,query=None):
        print("Performing MMR Search")
        docs = self.vector_store.max_marginal_relevance_search(query=query,k=self.topk,fetch_k=2048) # type: ignore
        print(f"Query Used: {query}, TOPK = {self.topk}")
        print(f"Length of Docs obtained = {len(docs)}")
        return docs
