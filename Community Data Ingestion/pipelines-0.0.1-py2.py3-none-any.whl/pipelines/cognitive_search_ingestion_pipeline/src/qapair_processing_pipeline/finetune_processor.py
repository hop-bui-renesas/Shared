import json 
from datasets import Dataset, concatenate_datasets
import re

class FineTunePrep():

    def __init__(self):
        self.files = []
        self.full_dataset = None
                
    def apply_prompt_template(self, examples):
        system_message = "Below is a question from a technical user of our company product set. Please write a response that appropriately answers the question\n\n"
        question = f"### Question: \n {examples['question']}\n\n"
        response = f"### Response: {examples['answer']}"

        return { "text": system_message + question + response}
    
    def create_finetune_dataset(self, file):
        self.files.append(file)
        data = []
        dataset = None
        with open(file, encoding="ascii", errors='ignore') as f:
            for i, line in enumerate(f):
                data.append(json.loads(line))
                text = data[i]['response']
                cleaned_text = self.clean_text(text)
                data[i]['response'] = cleaned_text
            f.close()
        
        # Filter out data with 'FAQ' in instruction or empty instruction
        data = [d for d in data if ('FAQ' not in d['instruction'])]
        data = [d for d in data if (d['instruction'] != "")]
        data = [d for d in data if (d['response'] != "")]
        
        dataset = Dataset.from_list(data)
        formatted_dataset = dataset # .map(self.apply_prompt_template)
        
        if self.full_dataset == None:
            self.full_dataset = formatted_dataset
        else:
            self.full_dataset = concatenate_datasets([self.full_dataset, formatted_dataset])
        
        formatted_dataset = self.full_dataset

        return formatted_dataset

    def clean_text(self, text):
        # 52 records less than length of 7 most of which contain negligible information such as only a name or email 
        if ("@" in text) or (len(text.split()) < 7):
            return ""
        cleaned_text = re.sub(r"[^\w\s-]", "", text)
        cleaned_text = re.sub(r"\xa0", " ", cleaned_text)
        cleaned_text = re.sub(r"Suitable Product.*", "", cleaned_text, flags=re.DOTALL).strip()
        cleaned_text = re.sub(r"Last Updated.*", "", cleaned_text).strip()
        cleaned_text = re.sub(r"Go to.*", "", cleaned_text, flags=re.DOTALL).strip()
        cleaned_text = re.sub(r"\[Tags\].*", "",cleaned_text, flags = re.DOTALL).strip()
        cleaned_text = re.sub(r"Tags.*", "", cleaned_text, flags=re.DOTALL).strip()
        return cleaned_text