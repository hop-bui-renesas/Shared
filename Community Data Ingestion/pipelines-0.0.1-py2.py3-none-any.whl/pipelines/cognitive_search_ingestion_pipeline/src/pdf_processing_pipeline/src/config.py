import os

# form recognizer
# AZURE_FORM_RECOGNIZER_KEY = os.environ.get('FORM_RECOGNIZER_KEY', "3d1f5d0ea2934744bd6cb2f04e49b1eb")
# AZURE_FORM_RECOGNIZER_ENDPOINT = os.environ.get('FORM_RECOGNIZER_ENDPOINT', "https://cdi-prod-westus2-001.cognitiveservices.azure.com/")

# AZURE_FORM_RECOGNIZER_KEY = "3d1f5d0ea2934744bd6cb2f04e49b1eb"
# AZURE_FORM_RECOGNIZER_ENDPOINT = "https://cdi-prod-westus2-001.cognitiveservices.azure.com/"

AZURE_FORM_RECOGNIZER_KEY = "f25a49e15047432a9509b496dde0b2c5"
AZURE_FORM_RECOGNIZER_ENDPOINT = "https://cdi-prod-westus2-002.cognitiveservices.azure.com/"
# for chunks


chunk_overlap = 0
tokens_per_chunk = 512
splitter_model="multi-qa-mpnet-base-dot-v1"

CHUNK_PAGE_SIZE = 10
PDF_TABLES_FOLDER = "pdf_tables_firstlevel_v3"
SPLIT_PAGE_CHUNK_FOLDER = "split_page_chunks_firstlevel_v3"
SOURCE_DOCUMENT_LINK_PATH = "/Volumes/llm_poc_catalog_westus2/landing/databrickslandingsa-llm-container/all_product_family_url.xlsx"
# SOURCE_DOCUMENT_LINK_PATH = "./all_product_family_url.xlsx"
# for splitter chunker
huggingFaceModels = ["all-mpnet-base-v2",
                       "multi-qa-mpnet-base-dot-v1",
                       "multi-qa-distilbert-cos-v1",
                       "all-MiniLM-L6-v2",
                      "multi-qa-MiniLM-L6-cos-v1"]

# for embedding the model
sentenceTransformerModels=["BAAI/bge-large-en-v1.5"]

DEFAULT_SENTENCE_TRANSFORMER = os.environ.get("DEFAULT_SENTENCE_TRANSFORMER", "multi-qa-mpnet-base-dot-v1")
DEFAULT_EMBEDDING_MODEL=  "BAAI/bge-large-en-v1.5"
BGE_EMBEDDING_DIM = 1024

# renesas databricks
DATABRICKS_WORKSPACE_URL = os.environ.get("DATABRICKS_WORKSPACE_URL", "https://adb-2804723707680916.16.azuredatabricks.net")
DATABRICKS_PERSONAL_ACCESS_TOKEN = os.environ.get("DATABRICKS_PERSONAL_ACCESS_TOKEN", "dapi862bdd4b333124fa3219f9506547ffaf")

# renesas databricks
DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME = os.environ.get("DATABRICKS_VECTORSEARCH_ENDPOINT_NAME", "fae-vector-endpoint")
# DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME = os.environ.get("DATABRICKS_VECTORSEARCH_ENDPOINT_NAME", "vector_search_demo_endpoint")
DATABRICKS_CATALOG_SCHEMA = os.environ.get("DATABRICKS_CATALOG_SCHEMA","llm_poc_catalog_westus2.landing")
DATABRICKS_INDEX_NAME = os.environ.get("DATABRICKS_INDEX_NAME", "test_index_demo")

# deloitte databricks url
# DATABRICKS_WORKSPACE_URL = os.environ.get("DATABRICKS_WORKSPACE_URL", "https://dbc-adf4afbc-60f8.cloud.databricks.com")
# DATABRICKS_PERSONAL_ACCESS_TOKEN = os.environ.get("DATABRICKS_PERSONAL_ACCESS_TOKEN", "dapi68292d54d5c962bdd58173563991033e")

# deloitte databricks vectors
# DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME = os.environ.get("DATABRICKS_VECTORSEARCH_ENDPOINT_NAME", "my-vector")
# DATABRICKS_CATALOG_SCHEMA = os.environ.get("DATABRICKS_CATALOG_SCHEMA","uc_demos_mkandasamy.airlinedata")

