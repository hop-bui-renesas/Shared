import requests
import json
from concurrent.futures import ThreadPoolExecutor
import math
from tqdm import tqdm
import re
from bs4 import BeautifulSoup

from pipelines.cognitive_search_ingestion_pipeline.src.dialog_data_processing_pipeline.ForumProcessors import ForumFineTuneProcessor
from pipelines.cognitive_search_ingestion_pipeline.src.dialog_data_processing_pipeline.ForumProcessors import ForumRagProcessor

class ForumIngestor():
    """
    Primary class to ingest data from the Community Forums
    """
    # Forum_info is required in the format of: {"Forum name": "Forum ID", ...}
    def __init__(self, forum_info, page_size = 100, page_counter = 0, num_workers = 4, format_type = "finetune",
                 save_file = "Forum_Fine_Tuning_Dialogue.json", 
                 parent_dir = "/Volumes/llm_poc_catalog_westus2/landing/databrickslandingsa-llm-container/CommunityData"):
        """
        Initialize the class with the necessary parameters
        """
        self.save_file = save_file
        self.final_object = {"messages": []}
        self.forum_info = forum_info
        self.parent_dir = parent_dir
        self.urls = []
        self.all_threads = []
        self.pages_remaining = True
        self.num_workers = num_workers
        self.format_type = format_type
        self.forum_processor = None
        self.headers = {
            "Rest-User-Token": "a2JzZ2FqdWVxZWxwOWdybmR0YWp4bWU6RGVsb2l0dGUgQVBJ",
            "Content-Type": "application/json",
        }
        self.params = {
            "PageSize": page_size,
            "PageIndex": page_counter
        }
    def process_community_data(self):
        """
        Inputs: 
            - N/A
        Body: 
            - This is the main orchestration for the class variable
            - Given the JSON Object for the forum in the instantiation of the class, iterate through forums and for each
                request the thread content then in batches gather the associated replies through a separate API call
            - This process takes time as for each forum there are many threads, and for each thread there are many replies
                Both follow a one to many relationship
        Outputs: 
            - Write a JSON File containing the aggregated data for all threads and replies for each forum in the input
        """
        forums = self.forum_info

        for forum in forums.keys():
            self.page_counter = 0

            print(f"Processing forum: {forum}")
            forumId = forums[forum]
            url = f"https://community.renesas.com/api.ashx/v2/forums/{forumId}/threads.json"
            print(f"\tProcessing URL: {url}")
            self.urls.append(url)

            # Can get a max of 100 threads per page
            while self.pages_remaining:
                try: 
                    response = requests.get(url, headers=self.headers, params=self.params).json() # type: ignore
                    self.all_threads.extend(response['Threads'])
                    self.page_counter+=1
                    
                    self.params['PageIndex'] = self.page_counter
                    print("Counter Progress", self.page_counter)

                    if not len(response['Threads']) == 100:
                        self.pages_remaining = False
                except:
                    print("API request failed at: ", url)

            self.batch_thread_processing(forum)

        print(f"Writing to file: {self.save_file}")

        file_path = self.parent_dir + "/" + self.save_file
        with open(file_path, "w+") as f:
            json.dump(self.final_object,f,indent=4)
        # dbutils.fs.put(file_path, json_data, overwrite=True)
        return file_path

    def batch_thread_processing(self, forum):
        """
        Inputs: 
            - forum: the given forum that is being processed
        Body: 
            - process the dialogue in each of the threads content and append messages to the final object
        Outputs: 
            - The class variable final_object will contain all threads 
        """
        # Dump all files to JSON
        with open(f"{forum}.json","w+") as f:
            json.dump(self.all_threads,f,indent=4)
        # Process the aggregate threads
        thread_content = self.process_forum_threads_batch(self.all_threads)
        print("Thread Content Processed...", thread_content)
        # Create processor object based on format type
        if self.format_type == "finetune":
            self.forum_processor = ForumFineTuneProcessor(thread_content)
        else:
            self.forum_processor = ForumRagProcessor(thread_content)

        # Process the data
        self.forum_processor.process_dialogue(thread_content)
        self.final_object = self.forum_processor.final_object

        print("Done Processing Data!")

    def batch_generator(self, data, batch_size):
        """
        Inputs: 
            - data: the aggregated community forum threads to be batched
            - batch_size: the batch size based on the number of workers used
        Body: 
            - Generate batches of community forum threads
        Output:
            - Batches of community forums to be processed in parallel 
        """
        batch = []
        for item in data:
            batch.append(item)
            if len(batch) == batch_size:
                yield batch
                batch = []
        if batch:
            yield batch

    def process_forum_threads_single_batch(self, thread_batch):
        """
        Inputs: 
            - thread_batch: individual batch of community forum threads 
        Body: 
            - For each thread request the replies API, pre process data filtering for only necessary information
              and aggregate into a combined thread and reply object 
        Outputs: 
            - batch_threads_and_replies: a list of JSON which contains the thread information and replies as a nested
              JSON object for further processing
        """
        batch_threads_and_replies = []
        #for each thread in thread_batch, get the url and then send the request to process_replies_given_thread
        for thread in thread_batch:
            # Extract thread information needed
            content_id = thread['ContentId']
            subject = thread['Subject']
            body = thread['Body']
            author_id = thread['Author']['Id']
            thread_id = thread['Id']
            forum_id = thread['ForumId']
            url = thread['Url']

            # Extract the thread id from the JSON
            
            response_url = f"https://community.renesas.com/api.ashx/v2/forums/{forum_id}/threads/{thread_id}/replies.json"
            thread_replies = self.process_replies_given_thread(get_url=response_url)

            # combine the Thread and its replies
            thread_and_reply = {"ContentId": content_id, 
                                "Subject": subject, 
                                "Url": url,
                                "Body": body, 
                                "AuthorId": author_id, 
                                "Replies": thread_replies,
                                "ThreadId": thread_id}
            batch_threads_and_replies.append(thread_and_reply)

        return batch_threads_and_replies

    def process_forum_threads_batch(self, threads):
        """
        Inputs: 
            - Threads: All thread information for a given forum returned from the API requests
        Body: 
            - Using multiple workers, call the single batch processing for the forum threads
            - Upon completion aggregate the combined threads and replies into a single list
        Outputs: 
            - all_content: a list containing the filtered and pre - processing Thread & Replies for a single forum
        """
        print("Beginning to process thread batches...")
        #Split threads into Worker Batches
        batch_size = math.ceil(len(threads)/self.num_workers)
        #create batches of utmost batch_size, which is list of lists
        forum_thread_batches_list = []
        for batch in self.batch_generator(threads, batch_size):
            # Process each batch
            forum_thread_batches_list.append(batch)

        # Spread processing across workers in batches    
        with ThreadPoolExecutor(max_workers=self.num_workers) as executor:
            batch_replies_list = list(tqdm(executor.map(self.process_forum_threads_single_batch, forum_thread_batches_list)))
        
        print("Batch Processing Completed...")
        # combine all threads into a single list (Thread body and replies included)
        all_content = []
        for batch in batch_replies_list:
            for replies in batch:
                all_content.append(replies)
        return all_content

    def process_replies_given_thread(self, get_url):
        """
        This function does not leverage the class variables, it only uses local variables

        Inputs: get_url - the URL to request the replies for a given thread

        Body: This function is designed to process the replies for a given thread
        - Re initialize the page counter and pages remaining as it is a sub thread (could move to its own class variable)

        Outputs: processed_replies - a list of JSON objects containing the necessary information for the replies
        """
        processed_replies = []
        page_counter = 0
        pages_remaining = True
        all_replies = []

        headers = {
            "Rest-User-Token": "a2JzZ2FqdWVxZWxwOWdybmR0YWp4bWU6RGVsb2l0dGUgQVBJ",
            "Content-Type": "application/json",
        }
        params = {
            "PageSize": "100",
            "PageIndex": page_counter
        }

        while pages_remaining:
            try: 
                response = requests.get(get_url, headers=headers, params=params).json()
                all_replies.extend(response['Replies'])
                page_counter+=1
                
                params['PageIndex'] = page_counter
                # Testing
                if not len(response['Replies']) == 100:
                    pages_remaining = False
            except:
                print("API request failed at: ", get_url)
        
        # TODO - Process out the content needed from noise
        
        for reply in all_replies: 
            # Extract thread information needed
            content_id = reply['ContentId']
            subject = reply['Subject']
            url = reply['Url']
            body = reply['Body']
            author_id = reply['Author']['Id']
            reply_id = reply['Id']
            parent_id = reply['ParentId']

            processed_reply = {"ContentId": content_id, 
                                "Subject": subject, 
                                "Url": url,
                                "Body": body, 
                                "AuthorId": author_id,
                                "ReplyId": reply_id,
                                "ParentId": parent_id}
            processed_replies.append(processed_reply)

        return processed_replies

    def clean_body_text(self, body_text):
        """Removes HTML tags, handles breaks, and replaces link tags with src attributes while preserving link text."""

        soup = BeautifulSoup(body_text, "lxml")

        for a_tag in soup.find_all("a"):
            image_link = a_tag.get("href")        
            if image_link != None: 
                link_text = a_tag.text.strip()  # Extract link text
                modified_link = f"{link_text}: {image_link}"  # Combine link text and image link
                a_tag.replace_with(modified_link)

        # Handle <img> tags
        for img_tag in soup.find_all("img"):
            image_link = img_tag["src"]
            alt_text = img_tag.get("alt", "")  # Extract alt text (default to empty string if not present)
            modified_link = f"{alt_text}: {image_link}"
            img_tag.replace_with(modified_link)

            # Extract text from custom [quote ] [/quote] tags using regular expressions
        text = soup.get_text(strip=True)
        quote_pattern = r"\[quote\s+([^\]]*)\](.*?)\[\/quote\]"  # Match pattern with optional attributes
        matches = re.findall(quote_pattern, text, flags=re.DOTALL)  # Find all matches, including newlines
        for attributes, quote_text in matches:
            # Process attributes if needed (e.g., extract userid and url)
            text = text.replace(f"[quote {attributes}]", "\nQuote: ").replace("[/quote]", "\n")

        return text

    def create_response_hierarchy(self, thread_and_reply):
        """
        Creates a nested dictionary representing thread hierarchies with reply bodies,
        from a list of reply dictionaries.

        Args:
            replies: A list of dictionaries, where each dictionary contains:
                - 'ReplyId': The unique ID of the reply.
                - 'ParentId': The ID of the parent reply, or None if it's a root thread.
                - 'Body': The text content of the reply.

        Returns:
            A nested dictionary where keys are thread IDs and values are lists of dictionaries.
            Each inner dictionary contains 'ReplyId', 'ParentId', and 'Body'.
        """

        threads = {}
        replies = thread_and_reply['Replies']
        original_Id = thread_and_reply['ThreadId']

        # Set the initial key to the JSON hierarchy
        threads[original_Id] = []

        for reply in replies:
            reply_id = reply['ReplyId']
            parent_id = reply.get('ParentId')
            body = reply.get('Body')  # Extract body, handling potential absence

            if parent_id is None:
                threads[original_Id] = {
                    'ReplyId': reply_id,
                    'Body': self.clean_body_text(body)
                }
            else:
                threads.setdefault(parent_id, {}).update({
                    'ReplyId': reply_id,
                    'Body': self.clean_body_text(body),
                })

        return threads

    def process_dialogue(self, thread_and_reply): 
        """
            Args:
                thread_and_reply: A list of dictionaries, where each dictionary contains:
                    - 'Body': The text content of the reply.

            Returns:
                A list with nested dictionaries where keys are:
                    - role: defines user/chatbot
                    - content: the main text for the dialogue thread
        """

        # now process the additional data
        response_hierarchy = self.create_response_hierarchy(thread_and_reply)

        # 0 = user, 1 = chatbot
        user_or_chatbot = 0
        role = "user"
        processed_dialogue = []

        # Add in the original thread body
        first_entry = {"role": role, "content": self.clean_body_text(thread_and_reply['Body'])}
        processed_dialogue.append(first_entry)

        # Access and process the nested structure with reply bodies:
        for id in response_hierarchy:
            # if no replies, return
            if len(response_hierarchy[id]) == 0:
                return []
            user_or_chatbot = not user_or_chatbot
            if user_or_chatbot == 0:
                role = "user"
            else:
                role = "assistant"
            assigned_reply = {"role": role, "content": response_hierarchy[id]['Body']}
            processed_dialogue.append(assigned_reply)
        
        return processed_dialogue
