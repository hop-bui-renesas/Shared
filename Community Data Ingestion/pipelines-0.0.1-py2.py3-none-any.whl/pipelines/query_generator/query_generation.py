from pipelines.prompts_store.prompts import condense_question_system_prompt, condense_question_user_prompt
from langchain.memory import ConversationBufferMemory
from langchain.chains import LLMChain
from pipelines.llm_hub.llms import LLMHub
from langchain.prompts import PromptTemplate
from common_utils.logging_utils import logger


class QueryGenerator():
    def __init__(self):
        self.llm = LLMHub().databricks_llm()

    def generate_query(self, question, chat_history, system_prompt = condense_question_system_prompt, user_prompt = condense_question_user_prompt):

        # myprompt = system_prompt+"\n"+user_prompt
        # prompt_template = ( 
        #                     PromptTemplate.from_template(myprompt)
        #                     +"{chat_history}"
        #                     +"{question}"
        #                 )
        inst_prompt = """You are a Condensed Question Generator. Given a chat history of a conversation between a human and an AI assistant and a follow up question provided by the human, you must generate a condensed question based off of the history related to the given product.

### Instruction:
{instruction}

### Chat History: 
{chat_history}

### Response:
"""
        prompt_template = ( 
                            PromptTemplate.from_template(inst_prompt)
                        )

        chat_memory = ConversationBufferMemory(memory_key="chat_history")
        chain = LLMChain(llm = self.llm,
                                memory=chat_memory,
                                prompt=prompt_template,
                                verbose=False)
        logger.info(f"Chat History going inside Question Generator chain : {chat_history}")
        # chain_response = chain.predict(question=question)
        chain_response = chain({"instruction": question, "chat_history": chat_history})

        print(chain_response)
        # try:
        #         chat_history.append((question, chain_response["answer"]))
        # except Exception as e:
        #         logger.info("Chat history error")

        return chain_response, chat_history

    