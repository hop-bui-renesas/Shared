import os

DATABRICKS_WORKSPACE_URL = os.environ.get("DATABRICKS_WORKSPACE_URL", "https://adb-2804723707680916.16.azuredatabricks.net")
DATABRICKS_PERSONAL_ACCESS_TOKEN = os.environ.get("DATABRICKS_PERSONAL_ACCESS_TOKEN", "dapi862bdd4b333124fa3219f9506547ffaf")

DATABRICKS_MPT30B_ENDPOINT = os.environ.get("DATABRICKS_MPT30B_ENDPOINT", "databricks-mpt-30b-instruct")

DEBUG_MODE = False

DEFAULT_TEMPERATURE = 0.00001
DEFAULT_MAX_LENGTH = 512
DEFAULT_TOP_P = 1

DATABRICKS_MISTRAL_ENDPOINT = "databricks-mixtral-8x7b-instruct"
# DATABRICKS_MISTRAL_ENDPOINT = "databricks-dbrx-instruct"
# DATABRICKS_MISTRAL_ENDPOINT = "databricks-llama-2-70b-chat"
# DATABRICKS_MISTRAL_ENDPOINT = "mistral-7B-instruct-community-kb-data-finetuned"