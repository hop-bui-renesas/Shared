# from app.backend.config import MAX_OUTPUT_TOKENS
from .config import DEFAULT_MAX_LENGTH, DEFAULT_TEMPERATURE, DEFAULT_TOP_P, \
        DATABRICKS_MPT30B_ENDPOINT, DATABRICKS_WORKSPACE_URL, DATABRICKS_PERSONAL_ACCESS_TOKEN, \
        DATABRICKS_MISTRAL_ENDPOINT
from langchain_community.llms.databricks import Databricks
from langchain_community.chat_models.databricks import ChatDatabricks

class LLMHub():
    """Used for simple LLM Setup"""
    def __init__(self):
        pass

    def databricks_llm(self, temperature = DEFAULT_TEMPERATURE, max_length = DEFAULT_MAX_LENGTH):
        """Setup the Mosaic MPT 30B Instruct LLM"""
        llm = Databricks(host=DATABRICKS_WORKSPACE_URL, 
                         endpoint_name=DATABRICKS_MPT30B_ENDPOINT, 
                         api_token=DATABRICKS_PERSONAL_ACCESS_TOKEN,
                         temperature = temperature,
                         max_tokens = max_length,
                         )
        
        return llm
    
    def chat_databricks_llm(self, temperature = DEFAULT_TEMPERATURE, max_length = DEFAULT_MAX_LENGTH):
        """Setup the Mixtral 8x7B LLM"""
        llm = ChatDatabricks(endpoint=DATABRICKS_MISTRAL_ENDPOINT, 
                            max_tokens=max_length, 
                            host = DATABRICKS_WORKSPACE_URL, 
                            api_token=DATABRICKS_PERSONAL_ACCESS_TOKEN,
                            temperature=temperature)
        
        return llm
