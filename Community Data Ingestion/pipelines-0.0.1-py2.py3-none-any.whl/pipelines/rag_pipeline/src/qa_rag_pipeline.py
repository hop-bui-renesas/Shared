from common_utils.logging_utils import logger
from .config import DEFAULT_LLM_MODEL, DEFAULT_MAX_LENGTH, DEFAULT_TEMPERATURE, \
        DATABRICKS_MPT30B_ENDPOINT, DATABRICKS_WORKSPACE_URL, DATABRICKS_PERSONAL_ACCESS_TOKEN, DEBUG_MODE, \
        DATABRICKS_CATALOG_SCHEMA, DATABRICKS_INDEX_NAME
from .retrieval_search import RetrievalSearch
from pipelines.prompts_store.prompts import rag_system_prompt, rag_user_prompt, condense_question_system_prompt, condense_question_user_prompt, \
    rag_system_prompt_v2, rag_user_prompt_v2
from langchain.memory import ConversationBufferMemory
from langchain.chains import (
    ConversationalRetrievalChain, RetrievalQA, LLMChain
)
from transformers import AutoTokenizer, pipeline
from langchain_community.llms.huggingface_pipeline import HuggingFacePipeline
from langchain_community.llms.databricks import Databricks
from pipelines.llm_hub.llms import LLMHub
from langchain.prompts import PromptTemplate
import json
from collections import OrderedDict
import ast
import re

class QARAGPipeline():

    def __init__(self, index = DATABRICKS_INDEX_NAME, reranker = True) -> None:
        index = DATABRICKS_CATALOG_SCHEMA+"."+index

        if reranker == True:
            self.topk = 20
            self.top_n = 4
        elif reranker == False:
            self.topk = 4
            self.top_n = 4
        logger.info(f"Values for TopK & Top N : {self.topk}, {self.top_n}")
        self.rag_search = RetrievalSearch(index_name=index, topk = self.topk, top_n = self.top_n)
        logger.info("RAG Retriever Initialized")

        self.reranker = reranker

        self.llm = LLMHub().databricks_llm()
    
    def get_huggingface_llm(self, llm_model_name = DEFAULT_LLM_MODEL, temperature = DEFAULT_TEMPERATURE, max_length = DEFAULT_MAX_LENGTH):

        tokenizer = AutoTokenizer.from_pretrained(llm_model_name, padding=True, truncation=True, max_length=max_length)

        question_answerer = pipeline(
            "question-answering", 
            model=llm_model_name, 
            tokenizer=tokenizer,
            return_tensors='pt'
        )
        llm = HuggingFacePipeline(
            pipeline=question_answerer,
            model_kwargs={"temperature": temperature, "max_length": max_length},
        )
        return llm
    
    def retrieval_qa(self, question, system_prompt, user_prompt, retriever):

        myprompt = system_prompt+"\n"+user_prompt
        # print(PromptTemplate.from_template(myprompt))
        prompt_template = (PromptTemplate.from_template(myprompt)                
                          )
        chain_type_kwargs = {"prompt": prompt_template,
                                 "verbose": DEBUG_MODE}
        # print(chain_type_kwargs)
        chain = RetrievalQA.from_chain_type(llm=self.llm, retriever=retriever,
                                                chain_type_kwargs=chain_type_kwargs,
                                                return_source_documents=True)
        chain_response = chain({'query': question})

        return chain_response
    
    def customize_response(self, response, base_retriever_out= None, chat_history = None):

        # logger.info(f"Inside the Customize Response : {response}")

        if chat_history is None:
             query = response.get('query')
             result = response.get('result')
        else:
             query = response.get('question')
             result = response.get('answer')

        mt = response.get('source_documents')
        mt_data = []
        supporting_content = []

        if self.reranker == False:
            for i in mt:
                myjson =  ast.literal_eval(i.metadata['metadata'])
                myjson['source_document'] = myjson['filename']
                # myjson = json.loads(str(i.metadata['metadata']).replace('"', "'").replace("'", '"'))
                mt_data.append(myjson)
                # Return the page content
                supporting_content.append(i.page_content)
        elif self.reranker == True:
                base_retriever_metadata = []
                for i in base_retriever_out:
                    askjson = ast.literal_eval(i.metadata['metadata'])
                    base_retriever_metadata.append(askjson)

                support_chunks = [doc.page_content for doc in response.get('source_documents')]
                supporting_content.extend(support_chunks)

                ids = [doc.metadata["id"] for doc in response.get('source_documents')]
                relevance_score = [doc.metadata["relevance_score"] for doc in response.get('source_documents')]

                print("Reranked Index", ids)
                for index, relevance in zip(ids, relevance_score):
                    mtt = base_retriever_metadata[index]
                    mtt['relevance_score'] = relevance
                    mt_data.append(mtt)

                
        non_duplicate_metadata = list(OrderedDict((frozenset(item.items()),item) for item in mt_data).values())

        return {
            "query" : query,
            "response" : result,
            "chat_history" : chat_history,
            "metadata" : non_duplicate_metadata,
            "supporting_content": supporting_content
        }

    def conversational_qa(self, question, system_prompt, user_prompt, retriever, chat_history):

        myprompt = system_prompt+"\n"+user_prompt
        prompt_template = ( 
                            PromptTemplate.from_template(myprompt)
                            +"{chat_history}"
                            +"{question}"
                        )

        chat_memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True, output_key='answer')
        chain = ConversationalRetrievalChain.from_llm(self.llm,
                                                        retriever=retriever,
                                                        memory=chat_memory,
                                                        condense_question_prompt=prompt_template,
                                                        return_source_documents=True,
                                                        verbose=False)
        logger.info("Started Chain with Chat History")
        logger.info(f"Chat History going inside chain : {chat_history}")
        chain_response = chain({"question": question, "chat_history": chat_history})
        # logger.info(f"Response obtained: {response}")
        try:
                chat_history.append((question, chain_response["answer"]))
        except Exception as e:
                logger.info("Chat history error")

        return chain_response, chat_history

    def qa_pipeline(self, query, system_prompt = rag_system_prompt_v2, user_prompt = rag_user_prompt_v2, chat_history = None):
        query = re.sub(r'[?.!]', '', query) # remove ? from query
        retriever = self.rag_search.rag_retriever()

        if chat_history == None:
            if self.reranker == True:
                base_retriever_out = retriever.get_relevant_documents(query)
                # logger.info(base_retriever_out)
                compressed_reranked_retriever = self.rag_search.compress_reranker(retriever)

                response = self.retrieval_qa(question=query, system_prompt = system_prompt, user_prompt = user_prompt, retriever = compressed_reranked_retriever)

                formatted_response  = self.customize_response(response, base_retriever_out = base_retriever_out, chat_history = chat_history)
            
            elif self.reranker == False:
                response = self.retrieval_qa(question=query, system_prompt = system_prompt, user_prompt = user_prompt, retriever = retriever)

                formatted_response  = self.customize_response(response, chat_history = chat_history)

            print("Response from Retrieval QA", formatted_response)

            return formatted_response

        elif chat_history is not None:
            logger.info("Entering inside Chat History")
            if self.reranker == True:
                base_retriever_out = retriever.get_relevant_documents(query)
                # logger.info(base_retriever_out)
                compressed_reranked_retriever = self.rag_search.compress_reranker(retriever)

                response, chat_history = self.conversational_qa(question=query, system_prompt = condense_question_system_prompt, user_prompt = condense_question_user_prompt, retriever = compressed_reranked_retriever, chat_history = chat_history)

                formatted_response  = self.customize_response(response, base_retriever_out = base_retriever_out, chat_history = chat_history)
            
            elif self.reranker == False:
                response, chat_history = self.conversational_qa(question=query, system_prompt = condense_question_system_prompt, user_prompt = condense_question_user_prompt, retriever = retriever, chat_history=chat_history)

                formatted_response  = self.customize_response(response, chat_history = chat_history)

            print("Response from Conversational QA", formatted_response)

            return formatted_response

    