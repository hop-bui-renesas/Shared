import os

DEFAULT_EMBEDDING_MODEL = "BAAI/bge-large-en-v1.5"
DEFAULT_LLM_MODEL = "mosaicml/mpt-30b"

DEFAULT_TEMPERATURE = 0.2
DEFAULT_MAX_LENGTH = 512

# renesas databricks
DATABRICKS_WORKSPACE_URL = os.environ.get("DATABRICKS_WORKSPACE_URL", "https://adb-2804723707680916.16.azuredatabricks.net")
DATABRICKS_PERSONAL_ACCESS_TOKEN = os.environ.get("DATABRICKS_PERSONAL_ACCESS_TOKEN", "dapi862bdd4b333124fa3219f9506547ffaf")

# renesas databricks
DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME = os.environ.get("DATABRICKS_VECTORSEARCH_ENDPOINT_NAME", "fae-vector-endpoint")
# DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME = os.environ.get("DATABRICKS_VECTORSEARCH_ENDPOINT_NAME", "vector_search_demo_endpoint")
DATABRICKS_CATALOG_SCHEMA = os.environ.get("DATABRICKS_CATALOG_SCHEMA","llm_poc_catalog_westus2.landing")
DATABRICKS_INDEX_NAME = os.environ.get("DATABRICKS_INDEX_NAME", "test_index_demo")

# LLM MPT 30b
DATABRICKS_MPT30B_ENDPOINT = os.environ.get("DATABRICKS_MPT30B_ENDPOINT", "databricks-mpt-30b-instruct")

DEBUG_MODE = False




# deloitte databricks url
# DATABRICKS_WORKSPACE_URL = os.environ.get("DATABRICKS_WORKSPACE_URL", "https://dbc-adf4afbc-60f8.cloud.databricks.com")
# DATABRICKS_PERSONAL_ACCESS_TOKEN = os.environ.get("DATABRICKS_PERSONAL_ACCESS_TOKEN", "dapi68292d54d5c962bdd58173563991033e")

# deloitte databricks vectors
# DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME = os.environ.get("DATABRICKS_VECTORSEARCH_ENDPOINT_NAME", "my-vector")
# DATABRICKS_CATALOG_SCHEMA = os.environ.get("DATABRICKS_CATALOG_SCHEMA","uc_demos_mkandasamy.airlinedata")

