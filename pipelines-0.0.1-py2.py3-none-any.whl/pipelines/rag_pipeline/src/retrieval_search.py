from langchain.vectorstores.databricks_vector_search import DatabricksVectorSearch
from langchain_community.embeddings import HuggingFaceEmbeddings
from common_utils.logging_utils import logger
from .config import DATABRICKS_PERSONAL_ACCESS_TOKEN, DEFAULT_EMBEDDING_MODEL, \
    DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME, DATABRICKS_WORKSPACE_URL, \
    DATABRICKS_PERSONAL_ACCESS_TOKEN
from databricks.vector_search.client import VectorSearchClient

class RetrievalSearch():
    """Search on a vector store and returning relevant documents
       Inputs: 
       a. Search Query
       b. Selected List of documents by user to restrict search to -- applies only when you are interested in returning a retriever object
       c. Vector store index_name
       d. Top K parameter
    """
    def __init__(self,index_name,embeddings=DEFAULT_EMBEDDING_MODEL, topk=4, search_type="similarity"):
        try:
            self.embeddings= HuggingFaceEmbeddings(model_name = embeddings)
        except ValueError as e:
            logger.error("Error on Loading Huggingface Embedding Model")

        self.client = VectorSearchClient(workspace_url=DATABRICKS_WORKSPACE_URL, 
                                         personal_access_token=DATABRICKS_PERSONAL_ACCESS_TOKEN)
        

        try:
            listindexes = [idx['name'] for idx in self.client.list_indexes(name = DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME).get('vector_indexes', [])]
            print(listindexes)
            if index_name in listindexes:
                logger.info(f"Index : {index_name} exists inside Endpoint {DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME}")
                self.vs_index = self.client.get_index(
                                    endpoint_name=DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME,
                                    index_name=index_name)
                
                logger.info(f"VS Index : {self.vs_index}")

                self.vector_store = DatabricksVectorSearch(index=self.vs_index,
                                                    embedding=self.embeddings,
                                                    text_column="text",
                                                    columns=['metadata']
                                                            )
                logger.info(f"Vector Store Index {self.vector_store}")
            else:
                raise Exception("Index Name is not Matching, try with other Index Name")
        except Exception as e:
            logger.info(f"Exception: {e}")
            # logger.info(f"Index : {index_name} does not exists inside Endpoint {DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME}")

        self.topk=topk
        self.search_type=search_type

    def retrieve_similarity_search(self):
        search_kwargs={'k': self.topk}
        return self.vector_store.as_retriever(search_type=self.search_type,search_kwargs=search_kwargs)
    
    def retrieve_mmr_search(self, fetch_k = 2048, lambda_mult = 0.5):
        search_kwargs={'k': self.topk,'fetch_k':fetch_k, 'lambda_mult' : lambda_mult}
        return self.vector_store.as_retriever(search_type=self.search_type,search_kwargs=search_kwargs)
    
    def rag_retriever(self):
        search_kwargs={'k': self.topk,'fetch_k':2048}
        return self.vector_store.as_retriever(search_type=self.search_type,search_kwargs=search_kwargs)
    
    def rag_search_results(self,query=None):
        docs=self.vector_store.similarity_search(query=query,k=self.topk) # type: ignore
        return docs
    
    def rag_mmr_search_results(self,query=None):
        print("Performing MMR Search")
        docs = self.vector_store.max_marginal_relevance_search(query=query,k=self.topk,fetch_k=2048) # type: ignore
        print(f"Query Used: {query}, TOPK = {self.topk}")
        print(f"Length of Docs obtained = {len(docs)}")
        return docs
