from common_utils.logging_utils import logger
from .config import DEFAULT_LLM_MODEL, DEFAULT_MAX_LENGTH, DEFAULT_TEMPERATURE, \
        DATABRICKS_MPT30B_ENDPOINT, DATABRICKS_WORKSPACE_URL, DATABRICKS_PERSONAL_ACCESS_TOKEN, DEBUG_MODE, \
        DATABRICKS_CATALOG_SCHEMA, DATABRICKS_INDEX_NAME
from .retrieval_search import RetrievalSearch
from .prompts import rag_system_prompt, rag_user_prompt
from langchain.memory import ConversationBufferMemory, ConversationBufferWindowMemory
from langchain.chains import (
    ConversationalRetrievalChain, RetrievalQA, LLMChain
)
from transformers import AutoTokenizer, pipeline
from langchain_community.llms.huggingface_pipeline import HuggingFacePipeline
from langchain_community.llms.databricks import Databricks
from langchain.prompts import PromptTemplate
import json


class QARAGPipeline():

    def __init__(self, index = DATABRICKS_INDEX_NAME, topk = 4) -> None:
        index = DATABRICKS_CATALOG_SCHEMA+"."+index
        self.rag_search = RetrievalSearch(index_name=index, topk = topk)
        logger.info("RAG Retriever Initialized")

        self.llm = self.databricks_llm()
    
    def get_huggingface_llm(self, llm_model_name = DEFAULT_LLM_MODEL, temperature = DEFAULT_TEMPERATURE, max_length = DEFAULT_MAX_LENGTH):

        tokenizer = AutoTokenizer.from_pretrained(llm_model_name, padding=True, truncation=True, max_length=max_length)

        question_answerer = pipeline(
            "question-answering", 
            model=llm_model_name, 
            tokenizer=tokenizer,
            return_tensors='pt'
        )
        llm = HuggingFacePipeline(
            pipeline=question_answerer,
            model_kwargs={"temperature": temperature, "max_length": max_length},
        )
        return llm
    
    def databricks_llm(self, temperature = DEFAULT_TEMPERATURE, max_length = DEFAULT_MAX_LENGTH):
         
        llm = Databricks(host=DATABRICKS_WORKSPACE_URL, endpoint_name=DATABRICKS_MPT30B_ENDPOINT, 
                         api_token=DATABRICKS_PERSONAL_ACCESS_TOKEN,
                         temperature = temperature, max_tokens = max_length)
        
        return llm
    
    def retrieval_qa(self, question, system_prompt, user_prompt, retriever):

        myprompt = system_prompt+"\n"+user_prompt
        prompt_template = ( 
                            PromptTemplate.from_template(myprompt)
                            + "{context}"
                            + "{question}"
                          )
        chain_type_kwargs = {"prompt": prompt_template,
                                 "verbose": DEBUG_MODE}
        chain = RetrievalQA.from_chain_type(llm=self.llm, retriever=retriever,
                                                chain_type_kwargs=chain_type_kwargs,
                                                return_source_documents=True)
        chain_response = chain({'query': question})

        return chain_response
    
    def customize_response(self, response, chat_history = None):

        # print("Responses", response)

        mt = response.get('source_documents')
        mt_data = []
        for i in mt:
            myjson = json.loads(str(i.metadata['metadata']).replace('"', "'").replace("'", '"'))
            mt_data.append(myjson)

        return {
            "query" : response.get('query'),
            "response" : response.get('result'),
            "metadata" : mt_data,
            "chat_history" : chat_history
        }

    # def conversational_qa(self, q):

    #     chat_memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True, output_key='answer')
    #     chain = ConversationalRetrievalChain.from_llm(self.llm,
    #                                                     self.rag_search,
    #                                                     memory=chat_memory,
    #                                                     condense_question_prompt=condense_question_template,
    #                                                     return_source_documents=True,
    #                                                     verbose=False)
    #     logger.info("Started Chain")
    #     logger.info(f"Chat History going inside chain : {chat_history}")
    #     chain_response = chain({"question": question, "chat_history": chat_history})
    #     # logger.info(f"Response obtained: {response}")
    #     try:
    #             chat_history.append((question,response["answer"]))
    #     except Exception as e:
    #             logger.info("Chat history error")
    #             traceback.print_exc()

    def qa_pipeline(self, query, system_prompt = rag_system_prompt, user_prompt = rag_user_prompt, chat_history = None):

        if chat_history == None:
            retriever = self.rag_search.rag_retriever()
            response = self.retrieval_qa(question=query, system_prompt = system_prompt, user_prompt = user_prompt, retriever = retriever)

            formatted_response  = self.customize_response(response, chat_history)

            print("Response from Retrieval QA", formatted_response)

        return formatted_response

    