from .config import DEFAULT_EMBEDDING_MODEL, DEFAULT_SENTENCE_TRANSFORMER, \
    DATABRICKS_WORKSPACE_URL, DATABRICKS_PERSONAL_ACCESS_TOKEN, \
    DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME, DATABRICKS_CATALOG_SCHEMA, BGE_EMBEDDING_DIM
from langchain.vectorstores.databricks_vector_search import DatabricksVectorSearch
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import UnstructuredCSVLoader
from langchain.docstore.document import Document
from pydantic import ValidationError
from common_utils.logging_utils import logger
from langchain.text_splitter import SentenceTransformersTokenTextSplitter
from databricks.vector_search.client import VectorSearchClient
from itertools import chain
#from databricks import sql
from sqlalchemy.engine import create_engine

class Vectorizer():
    """Vectorize a collection of document already split and chunked       
       Inputs: 
       a. List of Langchain Document Objects
       b. Dictionary containing the list of tables and their meta data
       c. Vector store index_name

       Returns: 
          index_name: Name of the index that was created for the first time or that was updated
    """
    def __init__(self,documents,tables=None,index_name=None, embedding_model=None,splitter_model=None) -> None:
        self.emb_model = embedding_model if embedding_model else DEFAULT_EMBEDDING_MODEL
        self.splitter_model=splitter_model if splitter_model else DEFAULT_SENTENCE_TRANSFORMER
        logger.info(f'Embedding model at vectorizer {self.emb_model}')
        self.embeddings = HuggingFaceEmbeddings(model_name = self.emb_model)
        self.client = VectorSearchClient(workspace_url=DATABRICKS_WORKSPACE_URL, 
                                         personal_access_token=DATABRICKS_PERSONAL_ACCESS_TOKEN)
        if index_name is not None:
            self.index_name=index_name
            if index_name in [idx['name'] for idx in self.client.list_indexes(name = DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME).get('vector_indexes', [])]:
                logger.info(f"Index : {index_name} exists with that Endpoint {DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME}. Appending it")
                self.vs_index = self.client.get_index(
                                endpoint_name=DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME,
                                index_name=index_name)
                # print(self.vs_index, type(self.vs_index), self.vs_index.name)
                self.vector_store = DatabricksVectorSearch(index=self.vs_index,
                                                           embedding=self.embeddings,
                                                           text_column="text",
                                                           columns = ['metadata']
                                                           )
            else:
                logger.info(f"Creating new index: {self.index_name}")
                self.vs_index = self.create_index()
                self.vector_store = DatabricksVectorSearch(index=self.vs_index,
                                                           embedding=self.embeddings,
                                                           text_column="text",
                                                           columns = ['metadata']
                                                           )
        else:
            self.index_name=f"{DATABRICKS_CATALOG_SCHEMA}.bge_model"
            logger.info(f"Creating new index if index is None: {self.index_name}")
            self.vs_index = self.create_index()
            self.vector_store = DatabricksVectorSearch(index=self.vs_index,
                                                           embedding=self.embeddings,
                                                           text_column="text",
                                                           columns = ['metadata']
                                                           )
        self.documents=documents
        self.tables = tables

    def flatten_chain(self, nested_list):
        return list(chain.from_iterable(nested_list))

    def create_index(self):
        vs_index  = self.client.create_direct_access_index(
                endpoint_name=DEFAULT_DATABRICKS_VECTORSEARCH_ENDPOINT_NAME,
                index_name=self.index_name,
                primary_key="id",
                embedding_dimension=BGE_EMBEDDING_DIM,
                embedding_vector_column="text_vector",
                schema={
                    "id": "string",
                    "text": "string",
                    "text_vector": "array<float>",
                    "metadata": "string",
                },
            )
        return vs_index
    
    # def databricks_sql_connection(self):

    #     connection = sql.connect(
    #     server_hostname="adb-2804723707680916.16.azuredatabricks.net",
    #     http_path="/sql/1.0/warehouses/3d34628aae41697a",
    #     access_token="dapi862bdd4b333124fa3219f9506547ffaf",
    #     catalog="llm_poc_catalog_westus2", schema="landing")

    #     cursor = connection.cursor()
    #     return cursor
    
    def execute_query(self, cursor, query):
        if "SELECT" in query:
            cursor.execute(query)
            result = cursor.fetchall()
            resul = []
            for row in result:
               resul.append(row)
            return resul
        else:
            cursor.execute(query)

    def sql_alchemy_databricks_engine(self):
        catalog="llm_poc_catalog_westus2", 
        schema="landing", 
        access_token = "dapi862bdd4b333124fa3219f9506547ffaf",
        server_hostname = "adb-2804723707680916.16.azuredatabricks.net", 
        warehouse_id="3d34628aae41697a"
        http_path = "/sql/1.0/warehouses/395af97f637fc762"
        engine = create_engine(
            url = f"databricks://token:{access_token}@{server_hostname}?" +
                    f"http_path={http_path}&catalog={catalog}&schema={schema}"
            )
        
        logger.info("SqL alchemy Engine created")
        return engine

    def embedding_documents(self, documents):

        docs = [doc.page_content for doc in documents]
        metadata = [f"""{doc.metadata}""" for doc in documents]
        embeddings = self.embeddings.embed_documents(docs)
        logger.info("starting to sql")

        # print(metadata)
        # values = ",".join([f"('{str(x)}', '{y}', '{str(z)}')" for x, y, z in zip(docs, embeddings, metadata)])
        # values = ",".join([f"('hello', {y}, {str(z)})" for x, y, z in zip(docs, embeddings, metadata)])

        # for x, y, z in zip(docs, embeddings, metadata):

        # spark = SparkSession.builder.appName("Pandas to Spark").getOrCreate()
        import pandas as pd
        df = pd.DataFrame({"text" : docs, "text_vector" : embeddings, "metadata" : metadata})
        logger.info("starting to sql")
        engine = self.sql_alchemy_databricks_engine()

        print(df)

        df.to_sql("self_table1", con= engine, chunksize = 10, if_exists='append')

        # spark_df = spark.createDataFrame(df)
        # spark_df.write.saveAsTable("landing.us_cit")
        # query = f"""INSERT INTO llm_poc_catalog_westus2.landing.self_table2 VALUES {values}"""
        # cursor = self.databricks_sql_connection()
        # self.execute_query(cursor, query)
        logger.info("Query Executed")

    def index_documents_and_tables(self):
        # self.embedding_documents(self.documents)
        if self.vector_store is not None:
            try:
                logger.info(f"Total No of Chunked Documents : {len(self.documents)}")
                vector_index_creation = self.vector_store.add_documents(documents=self.documents, bulk_size=2000)
                if len(vector_index_creation) == 0:
                    logger.error("Vector Index Creation Failed on Documents. Check the Text and Metadata Type with Index DB")
                elif len(vector_index_creation) != len([doc.page_content for doc in self.documents]):
                    logger.error("Vector Index Creation Partially - Updated")
                else:
                    logger.info("Vector Index Creation Successfully")
            
            except ValueError as e:
                for doc in self.documents:
                    doc_splitter = SentenceTransformersTokenTextSplitter(model_name=self.splitter_model,chunk_overlap=0,tokens_per_chunk=512)
                    split_doc = doc_splitter.split_documents([doc])
                    vector_index_creation = self.vector_store.add_documents(split_doc)
                    if len(vector_index_creation) == 0:
                        logger.error("Vector Index Creation Failed on Documents. Check the Text and Metadata Type with Index DB")
                    elif len(vector_index_creation) != len([doc.page_content for doc in self.documents]):
                        logger.error("Vector Index Creation Partially - Updated")
                    else:
                        logger.info("Vector Index Creation Successfully")
        else:
            logger.info("Vector Store is None")

        # self.tables = None
        if self.tables is not None:
            # table_list = self.flatten_chain([i['Table'] for i in self.tables])
            logger.info("Table Indexing Started")
            table_list = self.tables.get('Table')
            metadata_list = self.tables.get('metadata')
            table_loaders=[]
            if len(table_list) > 0:
                for table_path, metadatas in zip(table_list, metadata_list):
                    loader=UnstructuredCSVLoader(table_path)
                    table=loader.load()
                    docs = [doc.page_content for doc in table]
                    # print(metadatas)
                    # meta = [{"metadata" : str(doc.metadata)} for doc in table] # unstructured metadata
                    meta = {"metadata" : str(metadatas)}
                    table = Document(page_content=docs[0], metadata=meta) # meta[0]
                    # logger.info(f"Tablessss {table}")
                    table_loaders.append(table)
                logger.info(f"Length of Table Loaders: {len(table_loaders)}")
                # print("Table Loaders", table_loaders)
                try:  
                    vector_index_creation = self.vector_store.add_documents(table_loaders)
                    if len(vector_index_creation) == 0:
                        logger.error("Vector Index Creation Failed on Tables. Check the Table Type with Index DB")
                    elif len(vector_index_creation) != len([doc.page_content for doc in table_loaders]):
                        logger.error("Vector Index Creation Partially - Updated - Tables")
                    else:
                        logger.info("Vector Index Creation Successfully")
                except ValueError as e:
                    logger.error("Entering inside except condition - Tables")
                    for table in table_loaders:
                        table_splitter = SentenceTransformersTokenTextSplitter(model_name=self.splitter_model,chunk_overlap=0,tokens_per_chunk=512)
                        split_tables = table_splitter.split_documents([table])
                        vector_index_creation = self.vector_store.add_documents(split_tables)
                        
                        if len(vector_index_creation) == 0:
                            logger.error("Vector Index Creation Failed on Tables. Check the Table Type with Index DB - except condition")
                        elif len(vector_index_creation) != len([doc.page_content for doc in split_tables]):
                            logger.error("Vector Index Creation Partially - Updated - Tables - except condition")
                        else:
                            logger.info("Vector Index Creation Successfully")
                    logger.info("Table Indexing Completed")
            else:
                logger.info("Tables list empty, skipping table indexing")    
        else:
            logger.info("No tables were loaded from the document")
        return self.vs_index.name
        