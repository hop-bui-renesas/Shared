import os
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from .config import AZURE_FORM_RECOGNIZER_KEY, AZURE_FORM_RECOGNIZER_ENDPOINT
import pandas as pd
import json
from common_utils.logging_utils import logger
from tabulate import tabulate
from concurrent.futures import ThreadPoolExecutor
import glob

class AzureFormRecognizer():
    # formatting function
    def __init__(self):
        self.document_analysis_client = DocumentAnalysisClient(
            endpoint=AZURE_FORM_RECOGNIZER_ENDPOINT, credential=AzureKeyCredential(AZURE_FORM_RECOGNIZER_KEY)
        )

        self.foldername = "pdf_tables"
        if not os.path.exists(self.foldername):
            os.mkdir(self.foldername)
        
    def table_extraction(self, pdf_path, result, page_chunk_count, page_url= None):
        # with open("results.json", "w") as f:
        #     json.dump(result.to_dict(), f)
        
        table_list = []
        metadata = []
        for index, table in enumerate(result.tables):
            # print(f"Table: {index}")
            df = pd.DataFrame()
            page_number_list = []
            for cell in table.cells:
                df.loc[cell.row_index, cell.column_index] = cell.content
                for i in cell.bounding_regions:
                    page_number_list.append(i.page_number)
            df.columns = df.iloc[0]
            df = df.drop(df.index[0])
            filename = os.path.join(self.foldername, f"{os.path.basename(pdf_path).strip('.pdf')}_page_{max(page_number_list)}_table_{index}.csv")
            # filename = f"{filename}"
            df.to_csv(filename)
            table_list.append(filename)
            if page_url == None:
                page_url == ""
            pdf_filename = "".join(os.path.basename(pdf_path).strip(".pdf").split("_")[0:-3]) + ".pdf"
            metadata.append({
                "source_document" : page_url,
                "filename" : pdf_filename,
                "page_number" : int(page_chunk_count) + int(max(page_number_list)),
                "section_header" : ""
            })
            # print(tabulate(df, headers='keys', tablefmt='fancy_grid'))

        # print({
        #     "Table" : table_list,
        #     "metadata" : metadata
        #     })
        return {
            "Table" : table_list,
            "metadata" : metadata
            }     
                       
    def text_extraction(self, pdf_path, result, page_chunk_count, page_url = None):
        
        total_page_content = []
        metadata = []
        for page in result.pages:
            total_page_content.append(" ".join([line.content for line in page.lines]).replace("\n", " ").replace("\t",""))
            if page_url == None:
                page_url == ""
            pdf_filename = "".join(os.path.basename(pdf_path).strip(".pdf").split("_")[0:-3]) + ".pdf"
            metadata.append({
                "source_document" : page_url,
                "filename" : pdf_filename,
                "page_number" : int(page_chunk_count) + int(page.page_number),
                "section_header" : ""
            })
        
        return {
            "Text" : total_page_content,
            "metadata" : metadata
            }
    
        # page_content_list=[page.get_text().replace("\n", " ").replace("\t","") for page in self.extracted_output.pages]
        # page_content_list = self.remove_garbage_text(page_content_list)
        # metadata_list = [{"source": self.input_file, "page":i+1} for i in range(len(self.extracted_output.pages))]  
    
    def thread_execution_call(self, pdf_path, page_chunk_count):

        logger.info(f"Processing PDF File: {pdf_path}")

        with open(pdf_path, "rb") as open_pdf_file:
            poller = self.document_analysis_client.begin_analyze_document(
                "prebuilt-layout", open_pdf_file
            )
            result = poller.result()
        
        logger.info("Text Extraction Started")
        text_output = self.text_extraction(pdf_path, result, page_chunk_count)
        logger.info("Text Extraction Completed")
        logger.info("Table Extraction Started")
        table_output = self.table_extraction(pdf_path, result, page_chunk_count)
        logger.info("Table Extraction Completed")
        self.document_analysis_client.close()

        return text_output, table_output

    def form_recognize(self, pdf_path, page_chunk_count):


        text_output, table_output = self.thread_execution_call(pdf_path, page_chunk_count)

        # logger.info("Form Recognizer Completed!!!")

        return text_output, table_output
    
        # logger.info("Form Recognizer Output: %s", form_recognizer_output)