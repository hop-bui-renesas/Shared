from .pdf_form_recognizer import AzureFormRecognizer
from .vectorizer import Vectorizer
from .config import splitter_model, tokens_per_chunk, chunk_overlap, DEFAULT_SENTENCE_TRANSFORMER, DEFAULT_EMBEDDING_MODEL, \
    DATABRICKS_CATALOG_SCHEMA, DATABRICKS_INDEX_NAME, CHUNK_PAGE_SIZE
import os
import json
import glob
from itertools import chain
from common_utils.logging_utils import logger
from langchain.text_splitter import SentenceTransformersTokenTextSplitter
import time
import fitz # for getting pdf_pages
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor

class PDFProcessingPipeline():

    def __init__(self, database_index = DATABRICKS_INDEX_NAME):

        logger.info(f"Splitter Model Config: {splitter_model}, Tokens Per Chunk: {tokens_per_chunk}")

        self.text_splitter = SentenceTransformersTokenTextSplitter(model_name=splitter_model,
                                                                   chunk_overlap=chunk_overlap,
                                                                   tokens_per_chunk=tokens_per_chunk)
        
        # self.database_index = DATABRICKS_CATALOG_SCHEMA+f".{DEFAULT_EMBEDDING_MODEL.split('/')[1]}"
        self.database_index = DATABRICKS_CATALOG_SCHEMA+"."+database_index
        self.sentence_transformer = DEFAULT_SENTENCE_TRANSFORMER
        self.embedding_model =DEFAULT_EMBEDDING_MODEL

    def flatten_chain(self, nested_list):
        return list(chain.from_iterable(nested_list))

    def chunker(self, documents):

        # page_content_list = self.flatten_chain([i['Text'] for i in documents])
        # metadata_list = self.flatten_chain([i['metadata'] for i in documents]) #because of vector search string

        page_content_list =  documents.get('Text') #[i['Text'] for i in documents]
        metadata_list =  documents.get('metadata') # [i['metadata'] for i in documents]
        meta = [{"metadata" : str(i)} for i in metadata_list]
        data = self.text_splitter.create_documents(texts=page_content_list, metadatas = meta) #metadatas=metadata_list

        # print("My data-------------------", data)
        # print("Type of data----------------", type(data))
        return data
    
    def split_pages(self, pdf_file, total_page_count, doc, chunk_page_size = 100):
        start = 0
        splitted_file = os.path.split(pdf_file)

        filename  = splitted_file[1].split(".")[0]

        if not os.path.exists(os.path.join(splitted_file[0], filename)):
            os.mkdir(os.path.join(splitted_file[0], filename))

        save_to = os.path.join(splitted_file[0], filename)

        splitted_pages = []
        page_chunk_count_list = []

        page_chunk_count = 0

        while start < total_page_count:
            with fitz.open() as doc_tmp:
                    end = start + chunk_page_size - 1
                    if end >= total_page_count:
                        end = total_page_count
                    doc_tmp.insert_pdf(doc, from_page=start, to_page=end, rotate=-1, show_progress=False)
                    file_name = f"{filename}_page_{start}_{end}.pdf"
                    file_name = os.path.join(save_to, file_name)
                    doc_tmp.save(file_name)
                    start = end + 1
                    splitted_pages.append(file_name)
                    page_chunk_count_list.append(page_chunk_count)
                    page_chunk_count = page_chunk_count + 1
        logger.info("Completed Splitting the PDF Pages")
        return splitted_pages, page_chunk_count_list
    
    def task_execution(self, pdf_file, page_chunk_count = 0):
            # form recognizer
            start_time = time.time()
            azure_form_recognizer = AzureFormRecognizer()
            logger.info("Form Recognizer Initialized")
            logger.info(f"Started Task Execution on {pdf_file}")
            documents, tables = azure_form_recognizer.form_recognize(pdf_file, page_chunk_count)
            logger.info(f"Time taken for Form Recognizer: {time.time() - start_time} Sec")
            
            logger.info("Chunking Process Started")
            start_time = time.time()
            splitted_docs = self.chunker(documents)
            logger.info("Chunking Process Completed")
            logger.info(f"Time taken for Chunking: {time.time() - start_time} Sec")

            # metadats = [doc.metadata for doc in splitted_docs]
            # logger.info("My Metadata after splitted---------------------", metadats)
            # logger.info(splitted_docs)

            logger.info("Vectorization initialized")

            start_time = time.time()
            vectorstore = Vectorizer(documents=splitted_docs, tables=tables, index_name=self.database_index,
                                    embedding_model=self.embedding_model, splitter_model=self.sentence_transformer)
            database_index = vectorstore.index_documents_and_tables()
            logger.info(f"Time taken to Vectorize & Indexing : {time.time() - start_time} Sec")

    def run_pipeline(self, pdf_folder_path):

        pdf_files_list = glob.glob(os.path.join(pdf_folder_path, "*.pdf"))

        # pdf_count = [i for i in range(len(pdf_files_list))]
        logger.info(f"Total PDF Files {len(pdf_files_list)}")
        start_here = time.time()
        for idx, pdf_file in enumerate(pdf_files_list, 1):
            doc = fitz.open(pdf_file)
            total_page_count = len([i for i in doc])
            logger.info(f"Total page count : {total_page_count}")
            if total_page_count > CHUNK_PAGE_SIZE:
                logger.info(f"Splitting PDFs : {pdf_file}")
                splitted_pages, page_chunk_count_list = self.split_pages(pdf_file, total_page_count, doc, chunk_page_size = CHUNK_PAGE_SIZE)
                if len(splitted_pages) > 0:
                    # for pdf, count in zip(splitted_pages, page_chunk_count_list):
                    #      self.task_execution(pdf, count)
                    with ThreadPoolExecutor(max_workers=4) as executor:
                        executor.map(self.task_execution, splitted_pages, page_chunk_count_list)
            else:
                 self.task_execution(pdf_file)
                 
        logger.info(f"Total Time taken to complete {len(pdf_files_list)} Documents : {time.time() - start_here} Sec")
        logger.info(f"All Documents Vectorized & Indexed Under : {self.database_index} !!!!")

