import pandas as pd
import re
import json
import logging
import sys
import os
from argparse import ArgumentParser
logger = logging.getLogger("log4j")

class QAPairProcessing():
    def __init__(self, ble_path, ra_path, jsonl_save_path):
        
        self.validate_input(ble_path, ra_path, jsonl_save_path)

        self.ble_df = pd.read_excel(ble_path, engine="openpyxl")
        self.ra_df = pd.read_excel(ra_path, engine="openpyxl")
        
        ble_filtered_list = ["DA14585/531 - Hardware", "DA14585/531 - Software", "DA14585/531 - RF"]
        
        #filtering the list
        self.ble_df = self.ble_df[self.ble_df['Knowledge Base Category Name'].isin(ble_filtered_list)]
        
        self.ra_df = self.ra_df[(self.ra_df['Knowledge Base Parent Category Name'] == "RA Family") &
                                (self.ra_df['Knowledge Base Category Name'].str.contains("RA|ra")) &
                                (self.ra_df['Is Visible on Hub'] == True)]
        
        self.jsonl_save_path = jsonl_save_path

    def validate_input(self, ble_path, ra_path, jsonl_save_path):
        if not os.path.exists(ble_path):
            raise Exception(f"The path {ble_path} does not exists")
        if not os.path.exists(ra_path):
            raise Exception(f"The path {ra_path} does not exists")
        if not os.path.exists(jsonl_save_path):
            raise Exception(f"The path {jsonl_save_path} does not exists")

    def extract_qa_pairs(self, df):
        try:
            text = df["Action Description"]
            title = df["Ticket Name"]
            # print("Title", title)
            match_question = re.search(
                r"question:(.*?)(?:answer:|$)", text, re.IGNORECASE | re.DOTALL
            )
            match_answer = re.search(r"answer:(.*$)", text, re.IGNORECASE | re.DOTALL)
            format_answer = {
                "question": match_question.group(1).strip() if match_question else title,
                "answer": match_answer.group(1).strip() if match_answer else text,
            }
            return format_answer
        except Exception as e:
            text = df["Action Description"]
            title = df["Ticket Name"]
            print(text)
            print(title)
            logger.error(f"Error in Extract QA Pairs : {e}")
            

    def convert_to_jsonl(self, df):
        # Convert DataFrame to JSONL format
        save_name = df[1]
        df = df[0]
        with open(os.path.join(self.jsonl_save_path, f"{save_name}.jsonl"), "w") as jsonl_file:
            for index, row in df.iterrows():
                json_data = row["QA_Pair"]
                json_line = json.dumps(json_data)
                jsonl_file.write(json_line + "\n")

        print(f"DataFrame converted to JSONL format and saved to {self.jsonl_save_path}")
        
    def main(self):
        print("Extracting QA Pairs")
        self.ble_df["QA_Pair"] = self.ble_df.apply(self.extract_qa_pairs, axis=1) # type: ignore
        self.ra_df['QA_Pair'] = self.ra_df.apply(self.extract_qa_pairs, axis=1) # type: ignore
        
        ble_save_name = "processed_ble"
        ra_save_name = "processed_ra"
        
        self.ble_df.to_csv(os.path.join(self.jsonl_save_path,f"{ble_save_name}.csv"), index = False)
        self.ra_df.to_csv(os.path.join(self.jsonl_save_path,f"{ra_save_name}.csv"), index = False)
        
        for i in [[self.ble_df, ble_save_name], [self.ra_df, ra_save_name]]:
            self.convert_to_jsonl(i)
        
if __name__ == "__main__":
    
    parser = ArgumentParser(description='Key-Value Pair Parser')
    parser.add_argument('-ble_path', '--ble_path', type=str, help='Knowledge Base : BLE File Path')
    parser.add_argument('-ra_path', '--ra_path', type=str, help='Knowledge Base : RA File Path')
    parser.add_argument('-jsonl_save_path', '--jsonl_save_path', type=str, help='Formatted data store Path')
    args = parser.parse_args()

    if not os.path.exists(args.jsonl_save_path):
        os.makedirs(args.jsonl_save_path)

    qa_pair_processing_class = QAPairProcessing(args.ble_path, args.ra_path, args.jsonl_save_path)
    qa_pair_processing_class.main()
    
    print("Finished processing the Knowledge Base QA Pairs")